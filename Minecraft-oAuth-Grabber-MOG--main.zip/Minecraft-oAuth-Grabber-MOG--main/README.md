## Video Tutorial

[<img src="https://img.youtube.com/vi/-pa60mDnm6U/maxresdefault.jpg" width="50%">](https://www.youtube.com/watch?v=-pa60mDnm6U "Now in Android: 55")

## Written Tutorial

1. Fork this repo  
2. Make a Microsoft Azure Application Registration https://portal.azure.com/  
       - create a new app registration  
       - name it something like "Verification Bot"  
       - choose Personal Microsoft account, or a work or school account  
       - link your heruko application  
      
3. Configure in index.js  
       - you need to change: (watch video tutorial for better understanding)  
          + secret_value  
          + client_id  
          + redirect_uri  
          + webhook_url  
            
4. Host the repo you forked on heroku  
5. Set up your fake discord server  
